function incrementButton(){
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML) || 0;
  let multiplier = parseInt(document.getElementById("multiply").innerHTML);
  let perClick = parseInt(document.getElementById("perClick").innerHTML); // Get the per-click value
  increment.innerHTML = currentValue + multiplier;
}

function subtractTwenty() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML);
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseInt(multiply.innerHTML);
  let currentPerClick = parseInt(document.getElementById("perClick").innerHTML);
  if (currentValue >= 20) {
    increment.innerHTML = currentValue - 20;
    multiply.innerHTML = currentMultiplier + 1; // Update with the incremented value
    let newPerClick = currentPerClick + 1;
    document.getElementById("perClick").innerHTML = newPerClick;
  }
}

function subtractTwohundred() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML);
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseInt(multiply.innerHTML); // Parse current multiplier
  let currentPerClick = parseInt(document.getElementById("perClick").innerHTML);
  if (currentValue >= 200) {
    increment.innerHTML = currentValue - 200;
    multiply.innerHTML = currentMultiplier + 15;
    let newPerClick = currentPerClick + 15;
    document.getElementById("perClick").innerHTML = newPerClick;
  }
}

function subtractOneThousand() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML);
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseInt(multiply.innerHTML); // Parse current multiplier
  let currentPerClick = parseInt(document.getElementById("perClick").innerHTML);
  if (currentValue >= 1250) {
    increment.innerHTML = currentValue - 1250;
    multiply.innerHTML = currentMultiplier + 75;
    let newPerClick = currentPerClick + 75;
    document.getElementById("perClick").innerHTML = newPerClick;
  }
}

function subtractTwentyThousand() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML);
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseInt(multiply.innerHTML); // Parse current multiplier
  let currentPerClick = parseInt(document.getElementById("perClick").innerHTML) || 0;
  if (currentValue >= 20000) {
    increment.innerHTML = currentValue - 20000;
    multiply.innerHTML = currentMultiplier + 7500;
    let newPerClick = currentPerClick + 7500;
    document.getElementById("perClick").innerHTML = newPerClick;
  }
}

function subtractFiveHundred() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML) || 0;
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseFloat(multiply.innerHTML);
  let currentPerClick = parseFloat(document.getElementById("perClick").innerHTML); // Parse current multiplier
  if (currentValue >= 500000) {
    increment.innerHTML = currentValue - 500000; // Correct subtraction
    multiply.innerHTML = currentMultiplier * 1.01; // Update with the incremented
    let newPerClick = currentPerClick * 1.01;
    document.getElementById("perClick").innerHTML = newPerClick;
  }
}

function subtractThreeHundred() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML) || 0;
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseFloat(multiply.innerHTML); // Parse current multiplier
    let currentPerClick = parseFloat(document.getElementById("perClick").innerHTML);
    if (currentValue >= 300000000) {
        increment.innerHTML = currentValue - 300000000;
        multiply.innerHTML = currentMultiplier * 1.1;
        let newPerClick = currentPerClick * 1.1;
        document.getElementById("perClick").innerHTML = newPerClick;
    }
}

function subtractFifteen() {
  let increment = document.getElementById("incrementText");
  let currentValue = parseInt(increment.innerHTML) || 0;
  let multiply = document.getElementById("multiply"); // Get the multiplier element
  let currentMultiplier = parseFloat(multiply.innerHTML); // Parse current multiplier
  let currentPerClick = parseFloat(document.getElementById("perClick").innerHTML);
    if (currentValue >= 15000000000) {
        increment.innerHTML = currentValue - 15000000000;
        multiply.innerHTML = currentMultiplier * 1.2;
        let newPerClick = currentPerClick * 1.2;
        document.getElementById("perClick").innerHTML = newPerClick;
    }
}

// server.mjs
import { createServer } from 'node:http';

const server = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Hello World!\n');
});

// starts a simple http server locally on port 3000
server.listen(3000, '127.0.0.1', () => {
  console.log('Listening on 127.0.0.1:3000');
});

// run with `node server.mjs`
